from django.http import HttpResponse
from django.shortcuts import render

import os
import json

# Create your views here.
def getDataImg(request, id):
    with open(f'{os.path.dirname(os.path.abspath(__file__))}/data/{id}/{id}.jpg', 'rb') as f:
        return HttpResponse(f.read(), content_type='image/jpeg');

def getDataJson(request, id):
    with open(f'{os.path.dirname(os.path.abspath(__file__))}./data/{id}/{id}.json', 'rb') as f:
        return HttpResponse(f.read(), content_type="application/json");

def getShort(request, id):
    with open(f'{os.path.dirname(os.path.abspath(__file__))}./data/{id}/{id}.json', 'r') as f:
        js = json.load(f)
        return HttpResponse(json.dumps({
            'title': js['short']['title'],
            'genre': js['short']['genre']
        }), content_type="application/json");

def getFilt(request):
    return HttpResponse(json.dumps({
        'filts': ['all', 'Programming', 'Branding'],
    }), content_type="application/json");

def getCatId(request):
    return HttpResponse(json.dumps({
        'data': {
            'all': [0, 1, 2, 3, 4],
            'Programming': [0, 1, 2],
            'Branding': [3, 4]
        }
    }), content_type="application/json");