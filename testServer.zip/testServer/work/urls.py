from itertools import count
from unicodedata import name
from django.urls import path, include
from .views import getDataImg, getDataJson, getCatId, getFilt, getShort

urlpatterns = [
    path('img/<int:id>', getDataImg, name="data"),
    path('data/<int:id>', getDataJson, name="data"),
    path('short/<int:id>', getShort),
    path('category/', getCatId),
    path('filters/', getFilt)
]